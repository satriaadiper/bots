import requests
from tqdm import tqdm
from pyrogram import Client, filters

api_id = "21093783"  # Replace with your API ID
api_hash = "08d33595ee4ddc2acf28cad6a2f78693"  # Replace with your API hash

app = Client("my_bot", api_id=api_id, api_hash=api_hash)

def download_video(video_url, file_name):
    response = requests.get(video_url, stream=True)
    total_size = int(response.headers.get('content-length', 0))
    block_size = 1024  # 1 KB
    progress_bar = tqdm(total=total_size, unit='B', unit_scale=True)

    with open(file_name, 'wb') as file:
        for data in response.iter_content(block_size):
            progress_bar.update(len(data))
            file.write(data)

    progress_bar.close()

@app.on_message(filters.video)
def handle_video(client, message):
    video = message.video
    file_id = video.file_id
    video_url = client.get_download_url(file_id)

    file_name = f"{file_id}.mp4"  # Generate file name based on file ID
    message.reply_text("Downloading...")
    message.reply_text(f"Size: {video.file_size / (1024 * 1024):.2f} MB")

    download_video(video_url, file_name)

    message.reply_text("Download complete!")

app.run()
