echo "
🔥 Unzip Bot 🔥

Copyright (c) 2022 - 2023 EDM115

--> Join @EDM115bots on Telegram
--> Follow EDM115 on Github
"
python3 -m unzipper
