# Copyright (c) 2023 EDM115
import os


class Config:
    APP_ID = int(os.environ.get("APP_ID" , 28888037))
    API_HASH = os.environ.get("API_HASH" , "9fbe164b5591df05fbd8577e3b1d6d21")
    BOT_TOKEN = os.environ.get("BOT_TOKEN" , "6335014250:AAEyABaS9zjc9iwe_5-N1TJKzkWvVZ1m8eU")
    LOGS_CHANNEL = int(os.environ.get("LOGS_CHANNEL" , -1001969718785))
    MONGODB_URL = os.environ.get("MONGODB_URL" , "mongodb+srv://poyan86856:NcCJJikB9cPwiN39@cluster0.mjgr4z0.mongodb.net/?retryWrites=true&w=majority")
    BOT_OWNER = int(os.environ.get("BOT_OWNER" , 6387027582))
    DOWNLOAD_LOCATION = f"{os.path.dirname(__file__)}/Downloaded"
    THUMB_LOCATION = f"{os.path.dirname(__file__)}/Thumbnails"
    TG_MAX_SIZE = 2097152000
    # Default chunk size (0.005 MB → 1024*6) Increase if you need faster downloads
    CHUNK_SIZE = 1024 * 1024 * 5  # 5 MB
    BOT_THUMB = f"{os.path.dirname(__file__)}/bot_thumb.jpg"
    MAX_CONCURRENT_TASKS = 50
    MAX_TASK_DURATION_EXTRACT = 45 * 60  # 45 minutes (in seconds)
    MAX_TASK_DURATION_MERGE = 90 * 60  # 1 hour 30 minutes (in seconds)
