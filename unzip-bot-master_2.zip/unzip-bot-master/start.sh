echo "
🔥 Unzip Bot 🔥

Copyright (c) 2022 - 2023 EDM115

--> Join @EDM115bots on Telegram
--> Follow EDM115 on Github
"
pip3 install -U setuptools 
pip install -U pip setuptools wheel 
pip3 install -r requirements.txt 
add-apt-repository universe 
apt update 
apt install -y p7zip-full p7zip-rar ffmpeg zstd
python3 -m unzipper
